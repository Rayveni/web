var table_data=[{level0:{value:"технари",type:"text"}},
{level0:{value:"гуманитарии",type:"text"}},
{level0:{value:"ckl",type:"button",params:{class:"button_link"}}},
{level0:{value:"cklsss",type:"input",params:{class:"button_link1"}}}
]

function generateTableHead(table, data) {
  let thead = table.createTHead();
  let row = thead.insertRow();
  for (let key of data) {
    let th = document.createElement("th");
    let text = document.createTextNode(key);
    th.appendChild(text);
    row.appendChild(th);
  }
  
let th = document.createElement("th");
    let text = document.createTextNode("dddd");
    th.appendChild(text);
    row.appendChild(th);
	create_btn(th,"add","test_f");
}

function generateTable(table, data) {
  for (let element of data) {
    let row = table.insertRow();
	generateRow(row,element)
  }
}

function generateRow(row, row_data) {

    for (key in row_data) {
        let cell = row.insertCell(),
        row_cell = row_data[key];

        if (row_cell["type"] == "text") {
            var insert_cell = document.createTextNode(row_cell["value"]);
        }
		else if (row_cell["type"] == "button") {
			var insert_cell = document.createElement("BUTTON");
			insert_cell.innerHTML=row_cell["value"];
			insert_cell.classList.add(row_cell["params"]["class"]);
}
		else if (row_cell["type"] == "input") {
			var insert_cell = document.createElement("INPUT");
			 insert_cell.setAttribute("type", "text");
			insert_cell.placeholder = row_cell["value"];

}
        cell.appendChild(insert_cell);
    }
}

function create_btn(parent_el,button_text,f_name) {
  var btn = document.createElement("BUTTON");
  btn.innerHTML = button_text;
  btn.value="test_btn"
  
 btn.addEventListener('click', function(){  window[f_name](this.value);}, false); 
  

 parent_el.appendChild(btn);
}

function test_f(param) {
 alert(param+"ss")
}


function add_input_row(table,row_data) {

    tr = table.insertRow(1)  // puts it at the start
generateRow(tr, row_data) 
}

let table = document.getElementById("main_table");
let data = Object.keys(table_data[0]);
generateTableHead(table, data);
generateTable(table, table_data);


